#!/bin/bash
# ============================================================
#  ETag — демонстрация оптимистичной блокировки
#  Todo Management API
#  Запуск:  bash curl_etag_tests.sh
#  (сервер должен быть запущен на http://localhost:5080)
# ============================================================

BASE="http://localhost:5080/api/todos"
PASS=0
FAIL=0

green()  { printf "\033[32m%s\033[0m\n" "$1"; }
red()    { printf "\033[31m%s\033[0m\n" "$1"; }
header() { printf "\n\033[1;36m══ %s ══\033[0m\n" "$1"; }

check() {
  local name="$1" expected="$2" actual="$3"
  if [ "$actual" = "$expected" ]; then
    green "  ✓ $name (HTTP $actual)"
    PASS=$((PASS+1))
  else
    red "  ✗ $name — ожидали $expected, получили $actual"
    FAIL=$((FAIL+1))
  fi
}

# ---------- 1. GET: получаем задачу и ETag ----------
header "1. GET /api/todos/1  → 200 + ETag"
RESP=$(curl -s -i "$BASE/1")
echo "$RESP" | head -20
ETAG=$(echo "$RESP" | grep -i '^ETag:' | tr -d '\r' | awk '{print $2}')
CODE=$(echo "$RESP" | head -1 | tr -d '\r' | awk '{print $2}')
check "GET возвращает 200" "200" "$CODE"
echo "  ETag = $ETAG"

# ---------- 2. GET с If-None-Match → 304 ----------
header "2. GET с If-None-Match: $ETAG  → 304 Not Modified"
CODE=$(curl -s -o /dev/null -w "%{http_code}" \
  -H "If-None-Match: $ETAG" "$BASE/1")
check "If-None-Match → 304" "304" "$CODE"

# ---------- 3. PUT без If-Match → 428 ----------
header "3. PUT без If-Match  → 428 Precondition Required"
CODE=$(curl -s -o /dev/null -w "%{http_code}" -X PUT "$BASE/1" \
  -H "Content-Type: application/json" \
  -d '{"title":"Без If-Match","priority":"Low","isCompleted":false}')
check "PUT без If-Match → 428" "428" "$CODE"

# ---------- 4. PUT с правильным If-Match → 200 ----------
header "4. PUT с If-Match: $ETAG  → 200 OK, новый ETag"
RESP=$(curl -s -i -X PUT "$BASE/1" \
  -H "Content-Type: application/json" \
  -H "If-Match: $ETAG" \
  -d '{"title":"Правка от A","description":"ETag test","priority":"High","isCompleted":false}')
echo "$RESP" | head -25
CODE=$(echo "$RESP" | head -1 | tr -d '\r' | awk '{print $2}')
NEW_ETAG=$(echo "$RESP" | grep -i '^ETag:' | tr -d '\r' | awk '{print $2}')
check "PUT с верным If-Match → 200" "200" "$CODE"
echo "  Новый ETag = $NEW_ETAG"

# ---------- 5. PUT со СТАРЫМ ETag → 412 (lost update prevention) ----------
header "5. PUT со СТАРЫМ If-Match: $ETAG  → 412 Precondition Failed"
RESP=$(curl -s -i -X PUT "$BASE/1" \
  -H "Content-Type: application/json" \
  -H "If-Match: $ETAG" \
  -d '{"title":"Правка от B (должна провалиться)","priority":"Low","isCompleted":true}')
echo "$RESP" | head -25
CODE=$(echo "$RESP" | head -1 | tr -d '\r' | awk '{print $2}')
check "PUT со старым ETag → 412" "412" "$CODE"

# ---------- 6. GET снова — убеждаемся, что правка B не применилась ----------
header "6. GET /api/todos/1  — текст должен быть «Правка от A»"
BODY=$(curl -s "$BASE/1")
echo "$BODY"
TITLE=$(echo "$BODY" | python3 -c "import sys,json; print(json.load(sys.stdin)['title'])" 2>/dev/null || echo "?")
if [ "$TITLE" = "Правка от A" ]; then
  green "  ✓ Lost update предотвращён (title = Правка от A)"
  PASS=$((PASS+1))
else
  red "  ✗ Ожидали title=Правка от A, получили: $TITLE"
  FAIL=$((FAIL+1))
fi

# ---------- итог ----------
header "ИТОГ"
echo "  Пройдено: $PASS"
echo "  Провалено: $FAIL"
if [ "$FAIL" -eq 0 ]; then
  green "Все тесты ETag пройдены ✓"
  exit 0
else
  red "Есть ошибки"
  exit 1
fi
