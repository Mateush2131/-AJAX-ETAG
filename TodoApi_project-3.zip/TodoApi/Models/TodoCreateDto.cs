namespace TodoApi.Models;

/// <summary>
/// DTO для создания новой задачи.
/// </summary>
public class TodoCreateDto
{
    /// <summary>Название задачи (обязательно)</summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>Описание</summary>
    public string? Description { get; set; }

    /// <summary>Приоритет: Low, Medium, High</summary>
    public string Priority { get; set; } = "Medium";
}
