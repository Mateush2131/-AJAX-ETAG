namespace TodoApi.Models;

/// <summary>
/// DTO для обновления задачи (PUT).
/// </summary>
public class TodoUpdateDto
{
    public string Title { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string Priority { get; set; } = "Medium";
    public bool IsCompleted { get; set; }
}
