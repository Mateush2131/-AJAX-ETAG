namespace TodoApi.Models;

/// <summary>
/// Элемент списка задач (Todo).
/// </summary>
public class TodoItem
{
    /// <summary>Уникальный идентификатор задачи</summary>
    public long Id { get; set; }

    /// <summary>Название задачи</summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>Подробное описание</summary>
    public string? Description { get; set; }

    /// <summary>Выполнена ли задача</summary>
    public bool IsCompleted { get; set; }

    /// <summary>Дата создания</summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>Приоритет: Low, Medium, High</summary>
    public string Priority { get; set; } = "Medium";

    /// <summary>Версия для ETag (оптимистичная блокировка)</summary>
    public int Version { get; set; } = 1;
}
