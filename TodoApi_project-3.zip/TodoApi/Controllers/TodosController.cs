using Microsoft.AspNetCore.Mvc;
using TodoApi.Models;

namespace TodoApi.Controllers;

/// <summary>
/// API для управления задачами (Todo) с поддержкой ETag.
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class TodosController : ControllerBase
{
    private static readonly List<TodoItem> _todos = new()
    {
        new TodoItem
        {
            Id = 1,
            Title = "Изучить OpenAPI / Swagger",
            Description = "Настроить SwaggerGen и OpenApiInfo",
            IsCompleted = false,
            Priority = "High",
            CreatedAt = DateTime.UtcNow.AddDays(-1),
            Version = 1
        },
        new TodoItem
        {
            Id = 2,
            Title = "Написать контроллер Todos",
            Description = "CRUD-операции + ETag",
            IsCompleted = true,
            Priority = "Medium",
            CreatedAt = DateTime.UtcNow.AddDays(-2),
            Version = 1
        }
    };

    private static long _nextId = 3;

    /// <summary>Формирует strong ETag из версии: "v1", "v2", ...</summary>
    private static string GetETag(TodoItem item) => $"\"v{item.Version}\"";

    // ───────────── GET list ─────────────

    /// <summary>Получить все задачи (с фильтрами).</summary>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<TodoItem>), StatusCodes.Status200OK)]
    public ActionResult<IEnumerable<TodoItem>> GetAll(
        [FromQuery] bool? isCompleted = null,
        [FromQuery] string? priority = null)
    {
        var query = _todos.AsEnumerable();
        if (isCompleted.HasValue)
            query = query.Where(t => t.IsCompleted == isCompleted.Value);
        if (!string.IsNullOrWhiteSpace(priority))
            query = query.Where(t => t.Priority.Equals(priority, StringComparison.OrdinalIgnoreCase));
        return Ok(query.ToList());
    }

    // ───────────── GET by id + ETag / If-None-Match ─────────────

    /// <summary>
    /// Получить задачу по Id.
    /// Отдаёт ETag. При If-None-Match с тем же ETag → 304 Not Modified.
    /// </summary>
    [HttpGet("{id:long}")]
    [ProducesResponseType(typeof(TodoItem), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status304NotModified)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public ActionResult<TodoItem> GetById(long id)
    {
        var item = _todos.FirstOrDefault(t => t.Id == id);
        if (item is null)
            return NotFound(new { message = $"Задача с id={id} не найдена" });

        var etag = GetETag(item);
        Response.Headers.ETag = etag;

        // Клиент уже имеет актуальную версию — тело не отправляем
        var ifNoneMatch = Request.Headers.IfNoneMatch.ToString();
        if (!string.IsNullOrEmpty(ifNoneMatch) && ifNoneMatch == etag)
            return StatusCode(StatusCodes.Status304NotModified);

        return Ok(item);
    }

    // ───────────── POST create ─────────────

    /// <summary>Создать новую задачу.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(TodoItem), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public ActionResult<TodoItem> Create([FromBody] TodoCreateDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Title))
            return BadRequest(new { message = "Title обязателен" });

        var item = new TodoItem
        {
            Id = _nextId++,
            Title = dto.Title.Trim(),
            Description = dto.Description,
            Priority = string.IsNullOrWhiteSpace(dto.Priority) ? "Medium" : dto.Priority,
            IsCompleted = false,
            CreatedAt = DateTime.UtcNow,
            Version = 1
        };

        _todos.Add(item);
        Response.Headers.ETag = GetETag(item);
        return CreatedAtAction(nameof(GetById), new { id = item.Id }, item);
    }

    // ───────────── PUT update + If-Match (optimistic lock) ─────────────

    /// <summary>
    /// Обновить задачу целиком.
    /// Требует заголовок If-Match с текущим ETag.
    /// 428 — нет If-Match; 412 — ETag не совпал (конфликт).
    /// </summary>
    [HttpPut("{id:long}")]
    [ProducesResponseType(typeof(TodoItem), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status412PreconditionFailed)]
    [ProducesResponseType(428)]
    public ActionResult<TodoItem> Update(long id, [FromBody] TodoUpdateDto dto)
    {
        var item = _todos.FirstOrDefault(t => t.Id == id);
        if (item is null)
            return NotFound(new { message = $"Задача с id={id} не найдена" });

        var currentETag = GetETag(item);
        var clientETag = Request.Headers.IfMatch.ToString();

        // Клиент обязан прислать If-Match
        if (string.IsNullOrEmpty(clientETag))
        {
            return StatusCode(428, new
            {
                error = "Требуется заголовок If-Match",
                currentETag
            });
        }

        // Версии не совпали — кто-то уже изменил ресурс
        if (clientETag != currentETag)
        {
            return StatusCode(StatusCodes.Status412PreconditionFailed, new
            {
                error = "Документ был изменён другим клиентом",
                currentETag,
                yourETag = clientETag
            });
        }

        // Версии совпали — безопасно обновляем
        item.Title = string.IsNullOrWhiteSpace(dto.Title) ? item.Title : dto.Title.Trim();
        item.Description = dto.Description;
        item.Priority = string.IsNullOrWhiteSpace(dto.Priority) ? item.Priority : dto.Priority;
        item.IsCompleted = dto.IsCompleted;
        item.Version++;

        Response.Headers.ETag = GetETag(item);
        return Ok(item);
    }

    // ───────────── PATCH complete ─────────────

    /// <summary>Отметить задачу выполненной / невыполненной (тоже с If-Match).</summary>
    [HttpPatch("{id:long}/complete")]
    [ProducesResponseType(typeof(TodoItem), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status412PreconditionFailed)]
    [ProducesResponseType(428)]
    public ActionResult<TodoItem> SetCompleted(long id, [FromQuery] bool isCompleted = true)
    {
        var item = _todos.FirstOrDefault(t => t.Id == id);
        if (item is null)
            return NotFound(new { message = $"Задача с id={id} не найдена" });

        var currentETag = GetETag(item);
        var clientETag = Request.Headers.IfMatch.ToString();

        if (string.IsNullOrEmpty(clientETag))
            return StatusCode(428, new { error = "Требуется заголовок If-Match", currentETag });

        if (clientETag != currentETag)
            return StatusCode(StatusCodes.Status412PreconditionFailed, new
            {
                error = "Документ был изменён другим клиентом",
                currentETag,
                yourETag = clientETag
            });

        item.IsCompleted = isCompleted;
        item.Version++;
        Response.Headers.ETag = GetETag(item);
        return Ok(item);
    }

    // ───────────── DELETE + If-Match ─────────────

    /// <summary>Удалить задачу (требует If-Match).</summary>
    [HttpDelete("{id:long}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status412PreconditionFailed)]
    [ProducesResponseType(428)]
    public IActionResult Delete(long id)
    {
        var item = _todos.FirstOrDefault(t => t.Id == id);
        if (item is null)
            return NotFound(new { message = $"Задача с id={id} не найдена" });

        var currentETag = GetETag(item);
        var clientETag = Request.Headers.IfMatch.ToString();

        if (string.IsNullOrEmpty(clientETag))
            return StatusCode(428, new { error = "Требуется заголовок If-Match", currentETag });

        if (clientETag != currentETag)
            return StatusCode(StatusCodes.Status412PreconditionFailed, new
            {
                error = "Документ был изменён другим клиентом",
                currentETag,
                yourETag = clientETag
            });

        _todos.Remove(item);
        return NoContent();
    }
}
