using Microsoft.OpenApi.Models;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);

// Контроллеры
builder.Services.AddControllers();

// OpenAPI / Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Todo Management API",
        Version = "v1",
        Description = "API для управления задачами. Поддерживает фильтрацию и создание.\n\n" +
                      "## Возможности\n" +
                      "- Получение списка задач с фильтрами\n" +
                      "- Создание, завершение и удаление задач\n" +
                      "- In-memory хранилище (для демонстрации)",
        Contact = new OpenApiContact
        {
            Name = "API Support",
            Email = "support@example.com"
        },
        License = new OpenApiLicense
        {
            Name = "MIT",
            Url = new Uri("https://opensource.org/licenses/MIT")
        }
    });

    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    if (File.Exists(xmlPath))
        c.IncludeXmlComments(xmlPath);
});

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Todo Management API v1");
    c.RoutePrefix = "swagger";
});

app.MapControllers();

app.MapGet("/", () => Results.Redirect("/swagger"));

// Порт берётся из --urls / launchSettings / ASPNETCORE_URLS
// На macOS порт 5000 часто занят AirPlay — используй 5080
Console.WriteLine("========================================");
Console.WriteLine("  Todo Management API запущен");
Console.WriteLine("  Swagger UI: открой /swagger в браузере");
Console.WriteLine("  API base:   /api/todos");
Console.WriteLine("========================================");

app.Run();
