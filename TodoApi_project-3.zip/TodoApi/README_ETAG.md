# Todo Management API + ETag

Домашнее задание: реализация **ETag** (оптимистичная блокировка) в API задач.

## Что реализовано

| Заголовок | Метод | Поведение |
|-----------|-------|-----------|
| `ETag` в ответе | GET /api/todos/{id} | Strong ETag вида `"v1"`, `"v2"`, … |
| `If-None-Match` | GET | Если совпадает → **304 Not Modified** |
| `If-Match` | PUT / PATCH / DELETE | Обязателен. Не совпал → **412**. Нет заголовка → **428** |

Поле `Version` в модели увеличивается при каждом успешном изменении.

## Запуск

```bash
dotnet run
# слушает http://localhost:5080
```

## Автотесты curl

```bash
# сервер должен быть запущен
bash curl_etag_tests.sh
```

## Ручные curl-тесты (для скриншотов / отчёта)

### 1. Читаем задачу — получаем ETag

```bash
curl -i http://localhost:5080/api/todos/1
```

Ответ:
```
HTTP/1.1 200 OK
ETag: "v1"
{"id":1,"title":"...","version":1,...}
```

### 2. Повторный GET с If-None-Match → 304

```bash
curl -i http://localhost:5080/api/todos/1 \
  -H 'If-None-Match: "v1"'
```

```
HTTP/1.1 304 Not Modified
```

### 3. PUT без If-Match → 428

```bash
curl -i -X PUT http://localhost:5080/api/todos/1 \
  -H 'Content-Type: application/json' \
  -d '{"title":"Без ETag","priority":"Low","isCompleted":false}'
```

```
HTTP/1.1 428 ...
{"error":"Требуется заголовок If-Match","currentETag":"\"v1\""}
```

### 4. PUT с правильным If-Match → 200

```bash
curl -i -X PUT http://localhost:5080/api/todos/1 \
  -H 'Content-Type: application/json' \
  -H 'If-Match: "v1"' \
  -d '{"title":"Правка от A","description":"ok","priority":"High","isCompleted":false}'
```

```
HTTP/1.1 200 OK
ETag: "v2"
{"id":1,"title":"Правка от A","version":2,...}
```

### 5. PUT со СТАРЫМ ETag → 412 (предотвращение lost update)

```bash
curl -i -X PUT http://localhost:5080/api/todos/1 \
  -H 'Content-Type: application/json' \
  -H 'If-Match: "v1"' \
  -d '{"title":"Правка от B","priority":"Low","isCompleted":true}'
```

```
HTTP/1.1 412 Precondition Failed
{"error":"Документ был изменён другим клиентом","currentETag":"\"v2\"","yourETag":"\"v1\""}
```

### 6. Проверяем, что правка B не применилась

```bash
curl -s http://localhost:5080/api/todos/1 | python3 -m json.tool
# title должен быть "Правка от A"
```

## Сценарий lost update (без ETag vs с ETag)

**Без ETag:** A и B читают v1 → оба пишут → побеждает последний, правка A теряется.

**С ETag:** A пишет с If-Match: "v1" → OK, version=2.  
B пишет с If-Match: "v1" → **412**, правка A сохранена.
